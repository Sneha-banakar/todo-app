
package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

    @Test
    public void testValidLogin() {
        test = extent.createTest("Valid Login Test");
        driver.findElement(By.cssSelector("input[placeholder='Username']")).sendKeys("admin");
        driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("1234");
        driver.findElement(By.xpath("//button[text()='Login']")).click();

        boolean todoVisible = driver.getPageSource().contains("Todo List");
        Assert.assertTrue(todoVisible, "Login should succeed and show todo list.");
    }

    @Test
    public void testInvalidLogin() {
        test = extent.createTest("Invalid Login Test");
        driver.findElement(By.cssSelector("input[placeholder='Username']")).sendKeys("wrong");
        driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("wrong");
        driver.findElement(By.xpath("//button[text()='Login']")).click();

        boolean errorVisible = driver.getPageSource().contains("Invalid credentials");
        Assert.assertTrue(errorVisible, "Login should fail with invalid credentials.");
    }
}
