
package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TodoTests extends BaseTest {

    @BeforeMethod
    public void login() {
        driver.findElement(By.cssSelector("input[placeholder='Username']")).sendKeys("admin");
        driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("1234");
        driver.findElement(By.xpath("//button[text()='Login']")).click();
    }

    @Test
    public void testCreateItem() throws InterruptedException {
        test = extent.createTest("Create Item Test");

        String todoText = "Buy milk";
        driver.findElement(By.cssSelector("input[placeholder='Enter item text']")).sendKeys(todoText);
        driver.findElement(By.xpath("//button[text()='Add']")).click();
        Thread.sleep(10000);

        boolean found = driver.getPageSource().contains(todoText);
        Assert.assertTrue(found, "New todo item should appear in the list.");
    }

    @Test
    public void testEditItem() throws InterruptedException {
        test = extent.createTest("Edit Item Test");
Thread.sleep(10000);
        String updatedText = "Updated item";
        driver.findElement(By.xpath("//button[text()='Edit']")).click();
        driver.findElement(By.cssSelector("input[placeholder='Enter item text']")).clear();
        driver.findElement(By.cssSelector("input[placeholder='Enter item text']")).sendKeys(updatedText);
        driver.findElement(By.xpath("//button[text()='Update']")).click();

        boolean found = driver.getPageSource().contains(updatedText);
        Assert.assertTrue(found, "Item should be updated with new text.");
    }

    @Test
    public void testDeleteItem() throws InterruptedException {
        test = extent.createTest("Delete Item Test");

        Thread.sleep(10000);
        String deleteItemText = driver.findElement(By.cssSelector("ul li")).getText();
        driver.findElement(By.xpath("//button[text()='Delete']")).click();
        Thread.sleep(10000);
        boolean stillExists = driver.getPageSource().contains(deleteItemText);
        Assert.assertFalse(stillExists, "Item should be deleted.");
    }
}
